import React, { useState, useEffect } from 'react';

import Login from '../Login';
import Dashboard from '../Dashboard';

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const columns=[
    {
      label:"First Name",
      field:"firstName",
      type:"text"
    },
    {
      label:"Last Name",
      field:"lastName",
      type:"text"
    },
    {
      label:"Email",
      field:"email",
      type:"email"
    },
    {
      label:"Salary",
      field:"salary",
      type:"number"
    },
    {
      label:"Date",
      field:"date",
      type:"date"
    },
  ]

  const expenses = [
    {
      label: "Description",
      field: "description",
      type: "text",
    },
    {
      label: "Category",
      field: "category",
      type: "text",
    },
    {
      label: "Amount",
      field: "amount",
      type: "number",
    },
    {
      label: "Month",
      field: "month",
      type: "text",
    },
    {
      label: "Year",
      field: "year",
      type: "number",
    },
  ];

  const budget = [
    
    {
      label: "Category",
      field: "category",
      type: "text",
    },
    {
      label: "Amount",
      field: "amount",
      type: "number",
    },
    {
      label: "Month",
      field: "month",
      type: "text",
    },
    {
      label: "Year",
      field: "year",
      type: "number",
    },
  ];

  useEffect(() => {
    setIsAuthenticated(JSON.parse(localStorage.getItem('is_authenticated')));
  }, []);

  return (
    <>
      {isAuthenticated ? (
        <Dashboard setIsAuthenticated={setIsAuthenticated} columns={expenses} endpoint={'expenses'} title={'Expenses'}/>
      ) : (
        <Login setIsAuthenticated={setIsAuthenticated} />
      )}
    </>
  );
};

export default App;
