import React, { useState } from "react";
import Swal from "sweetalert2";
import axios from "axios";
import config from "../../config.json";
const Edit = ({
  data,
  selectedData,
  setdata,
  setIsEditing,
  columns,
  endpoint,
  title
}) => {
  const id = selectedData.id;
  let x = {};
  columns.map((column) => {
    return (x[column.field] = selectedData[column.field]);
  });
  const [empData, setEmpData] = useState(x);

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      // if (!firstName || !lastName || !email || !salary || !date) {
      //   return Swal.fire({
      //     icon: "error",
      //     title: "Error!",
      //     text: "All fields are required.",
      //     showConfirmButton: true,
      //   });
      // }
      const res = await axios.put(`${config.url}/${endpoint}/${selectedData._id}`, empData);

      for (let i = 0; i < data.length; i++) {
        if (data[i].id === id) {
          data.splice(i, 1, res.data);
          break;
        }
      }
      setdata(data);
      setIsEditing(false);

      Swal.fire({
        icon: "success",
        title: "Updated!",
        text: `data has been updated.`,
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (error) {
      console.error("Error during API request:", error);
      Swal.fire({
        icon: "error",
        title: "Error!",
        text: "Failed to update data. Please try again.",
        showConfirmButton: true,
      });
      // You might want to show an error message to the user or take other actions
    }
  };
  const handleEmp = (e) => {
    setEmpData({ ...empData, [e.target.name]: e.target.value });
  };

  return (
    <div className="small-container">
      <form>
        <h1>Edit {title}</h1>
        {columns.map((column, i) => (
          <div key={i}>
            <label htmlFor={column.field}>{column.label}</label>
            <input
              id={column.field}
              type={column.type}
              name={column.field}
              value={empData[column.field]}
              onChange={(e) => handleEmp(e)}
            />
          </div>
        ))}

        <div style={{ marginTop: "30px" }}>
          <input
            type="submit"
            value="Update"
            onClick={(e) => handleUpdate(e)}
          />
          <input
            style={{ marginLeft: "12px" }}
            className="muted-button"
            type="button"
            value="Cancel"
            onClick={() => setIsEditing(false)}
          />
        </div>
      </form>
    </div>
  );
};

export default Edit;
